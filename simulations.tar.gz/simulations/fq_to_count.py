#!/usr/bin/env python3

#this script will form comp files from fastq files by counting the number of reads belonging to each species and calculating abundance

#call script.py inputfile.fastq(.gz)

from Bio import SeqIO
import sys
import os
import gzip

infile = sys.argv[1]
#infile = "./test.fastq"
folderlocation = os.path.dirname(infile)
newfilename = (folderlocation  + infile[0:3] + "_seq_counts")
format = "fastq"

#declare counts and set to 0
ABXA01_count = 0
ABYP01_count = 0
ABYQ02_count = 0
ACDD01_count = 0
AEEH01_count = 0
AENP01_count = 0
AEXM01_count = 0
AGWL01_count = 0
AGWP01_count = 0
AGWQ01_count = 0
AGZR01_count = 0
AJVZ01_count = 0
AQVC01_count = 0
AQWR01_count = 0
ARGD01_count = 0
ATBY01_count = 0
ATIO01_count = 0
ATUF01_count = 0
ATUY01_count = 0
AUIB01_count = 0
AUME01_count = 0
AWXB01_count = 0
AZIS01_count = 0
BAIS01_count = 0
CBQQ01_count = 0
CP008802_count = 0
GCF_000005845_count = 0
GCF_000007325_count = 0
GCF_000007645_count = 0
GCF_000007785_count = 0
GCF_000008345_count = 0
GCF_000008525_count = 0
GCF_000009925_count = 0
GCF_000021265_count = 0
GCF_000024565_count = 0
GCF_000024945_count = 0
GCF_000027165_count = 0
GCF_000027305_count = 0
GCF_000092265_count = 0
GCF_000153885_count = 0
GCF_000153925_count = 0
GCF_000154805_count = 0
GCF_000156675_count = 0
GCF_000157995_count = 0
GCF_000159115_count = 0
GCF_000160035_count = 0
GCF_000160055_count = 0
GCF_000160075_count = 0
GCF_000160435_count = 0
GCF_000162015_count = 0
GCF_000163475_count = 0
GCF_000164675_count = 0
GCF_000164695_count = 0
GCF_000173915_count = 0
GCF_000174175_count = 0
GCF_000175635_count = 0
GCF_000177075_count = 0
GCF_000177375_count = 0
GCF_000186165_count = 0
GCF_000195995_count = 0
GCF_000196035_count = 0
GCF_000253395_count = 0
GCF_000376645_count = 0
GCF_000412995_count = 0
GCF_000516535_count = 0
GCF_000818035_count = 0
GRCh38_count = 0
JRMW01_count = 0
LOQF01_count = 0
LSDG01_count = 0
NC_000908_count = 0
NC_004368_count = 0
NC_013171_count = 0
NC_014246_count = 0
NC_017333_count = 0
NC_022239_count = 0
NZ_CM000955_count = 0
NZ_CP012195_count = 0

#viral counts
NC_007605_count = 0
NC_001526_count = 0
NC_022518_count = 0
NC_000898_count = 0
NC_014081_count = 0
NC_001405_count = 0
NC_003977_count = 0
NC_001802_count = 0
NC_002204_count = 0
NC_001357_count = 0



#open files and obtain headers as lists
with open('/gpfs/home/znb17pxu/reference-genomes/headers2/ABXA01.1.fsa_nt.fna.gz') as f:
    ABXA01 = f.read().splitlines()
with open('/gpfs/home/znb17pxu/reference-genomes/headers2/ABYP01.1.fsa_nt.fna.gz') as f:
    ABYP01 = f.read().splitlines()
with open('/gpfs/home/znb17pxu/reference-genomes/headers2/ABYQ02.1.fsa_nt.fna.gz') as f:
    ABYQ02 = f.read().splitlines()
with open('/gpfs/home/znb17pxu/reference-genomes/headers2/ACDD01.1.fsa_nt.fna.gz') as f:
    ACDD01 = f.read().splitlines()
with open('/gpfs/home/znb17pxu/reference-genomes/headers2/AEEH01.1.fsa_nt.fna.gz') as f:
    AEEH01 = f.read().splitlines()
with open('/gpfs/home/znb17pxu/reference-genomes/headers2/AENP01.1.fsa_nt.fna.gz') as f:
    AENP01 = f.read().splitlines()
with open('/gpfs/home/znb17pxu/reference-genomes/headers2/AEXM01.1.fsa_nt.fna.gz') as f:
    AEXM01 = f.read().splitlines()
with open('/gpfs/home/znb17pxu/reference-genomes/headers2/AGWL01.1.fsa_nt.fna.gz') as f:
    AGWL01 = f.read().splitlines()
with open('/gpfs/home/znb17pxu/reference-genomes/headers2/AGWP01.1.fsa_nt.fna.gz') as f:
    AGWP01 = f.read().splitlines()
with open('/gpfs/home/znb17pxu/reference-genomes/headers2/AGWQ01.1.fsa_nt.fna.gz') as f:
    AGWQ01 = f.read().splitlines()
with open('/gpfs/home/znb17pxu/reference-genomes/headers2/AGZR01.1.fsa_nt.fna.gz') as f:
    AGZR01 = f.read().splitlines()
with open('/gpfs/home/znb17pxu/reference-genomes/headers2/AJVZ01.1.fsa_nt.fna.gz') as f:
    AJVZ01 = f.read().splitlines()
with open('/gpfs/home/znb17pxu/reference-genomes/headers2/AQVC01.1.fsa_nt.fna.gz') as f:
    AQVC01 = f.read().splitlines()
with open('/gpfs/home/znb17pxu/reference-genomes/headers2/AQWR01.1.fsa_nt.fna.gz') as f:
    AQWR01 = f.read().splitlines()
with open('/gpfs/home/znb17pxu/reference-genomes/headers2/ARGD01.1.fsa_nt.fna.gz') as f:
    ARGD01 = f.read().splitlines()
with open('/gpfs/home/znb17pxu/reference-genomes/headers2/ATBY01.1.fsa_nt.fna.gz') as f:
    ATBY01 = f.read().splitlines()
with open('/gpfs/home/znb17pxu/reference-genomes/headers2/ATIO01.1.fsa_nt.fna.gz') as f:
    ATIO01 = f.read().splitlines()
with open('/gpfs/home/znb17pxu/reference-genomes/headers2/ATUF01.1.fsa_nt.fna.gz') as f:
    ATUF01 = f.read().splitlines()
with open('/gpfs/home/znb17pxu/reference-genomes/headers2/ATUY01.1.fsa_nt.fna.gz') as f:
    ATUY01 = f.read().splitlines()
with open('/gpfs/home/znb17pxu/reference-genomes/headers2/AUIB01.1.fsa_nt.fna.gz') as f:
    AUIB01 = f.read().splitlines()
with open('/gpfs/home/znb17pxu/reference-genomes/headers2/AUME01.1.fsa_nt.fna.gz') as f:
    AUME01 = f.read().splitlines()
with open('/gpfs/home/znb17pxu/reference-genomes/headers2/AWXB01.1.fsa_nt.fna.gz') as f:
    AWXB01 = f.read().splitlines()
with open('/gpfs/home/znb17pxu/reference-genomes/headers2/AZIS01.1.fsa_nt.fna.gz') as f:
    AZIS01 = f.read().splitlines()
with open('/gpfs/home/znb17pxu/reference-genomes/headers2/BAIS01.1.fsa_nt.fna.gz') as f:
    BAIS01 = f.read().splitlines()
with open('/gpfs/home/znb17pxu/reference-genomes/headers2/CBQQ01.1.fsa_nt.fna.gz') as f:
    CBQQ01 = f.read().splitlines()
with open('/gpfs/home/znb17pxu/reference-genomes/headers2/CP008802.1.fsa_nt.fna.gz') as f:
    CP008802 = f.read().splitlines()
with open('/gpfs/home/znb17pxu/reference-genomes/headers2/GCF_000005845.2_ASM584v2_genomic.fna.gz') as f:
    GCF_000005845 = f.read().splitlines()
with open('/gpfs/home/znb17pxu/reference-genomes/headers2/GCF_000007325.1_ASM732v1_genomic.fna.gz') as f:
    GCF_000007325 = f.read().splitlines()
with open('/gpfs/home/znb17pxu/reference-genomes/headers2/GCF_000007645.1_ASM764v1_genomic.fna.gz') as f:
    GCF_000007645 = f.read().splitlines()
with open('/gpfs/home/znb17pxu/reference-genomes/headers2/GCF_000007785.1_ASM778v1_genomic.fna.gz') as f:
    GCF_000007785 = f.read().splitlines()
with open('/gpfs/home/znb17pxu/reference-genomes/headers2/GCF_000008345.1_ASM834v1_genomic.fna.gz') as f:
    GCF_000008345 = f.read().splitlines()
with open('/gpfs/home/znb17pxu/reference-genomes/headers2/GCF_000008525.1_ASM852v1_genomic.fna.gz') as f:
    GCF_000008525 = f.read().splitlines()
with open('/gpfs/home/znb17pxu/reference-genomes/headers2/GCF_000009925.1_ASM992v1_genomic.fna.gz') as f:
    GCF_000009925 = f.read().splitlines()
with open('/gpfs/home/znb17pxu/reference-genomes/headers2/GCF_000021265.1_ASM2126v1_genomic.fna.gz') as f:
    GCF_000021265 = f.read().splitlines()
with open('/gpfs/home/znb17pxu/reference-genomes/headers2/GCF_000024565.1_ASM2456v1_genomic.fna.gz') as f:
    GCF_000024565 = f.read().splitlines()
with open('/gpfs/home/znb17pxu/reference-genomes/headers2/GCF_000024945.1_ASM2494v1_genomic.fna.gz') as f:
    GCF_000024945 = f.read().splitlines()
with open('/gpfs/home/znb17pxu/reference-genomes/headers2/GCF_000027165.1_ASM2716v1_genomic.fna.gz') as f:
    GCF_000027165 = f.read().splitlines()
with open('/gpfs/home/znb17pxu/reference-genomes/headers2/GCF_000027305.1_ASM2730v1_genomic.fna.gz') as f:
    GCF_000027305 = f.read().splitlines()
with open('/gpfs/home/znb17pxu/reference-genomes/headers2/GCF_000092265.1_ASM9226v1_genomic.fna.gz') as f:
    GCF_000092265 = f.read().splitlines()
with open('/gpfs/home/znb17pxu/reference-genomes/headers2/GCF_000153885.1_ASM15388v1_genomic.fna.gz') as f:
    GCF_000153885 = f.read().splitlines()
with open('/gpfs/home/znb17pxu/reference-genomes/headers2/GCF_000153925.1_ASM15392v1_genomic.fna.gz') as f:
    GCF_000153925 = f.read().splitlines()
with open('/gpfs/home/znb17pxu/reference-genomes/headers2/GCF_000154805.1_ASM15480v1_genomic.fna.gz') as f:
    GCF_000154805 = f.read().splitlines()
with open('/gpfs/home/znb17pxu/reference-genomes/headers2/GCF_000156675.1_ASM15667v1_genomic.fna.gz') as f:
    GCF_000156675 = f.read().splitlines()
with open('/gpfs/home/znb17pxu/reference-genomes/headers2/GCF_000157995.1_ASM15799v1_genomic.fna.gz') as f:
    GCF_000157995 = f.read().splitlines()
with open('/gpfs/home/znb17pxu/reference-genomes/headers2/GCF_000159115.1_ASM15911v1_genomic.fna.gz') as f:
    GCF_000159115 = f.read().splitlines()
with open('/gpfs/home/znb17pxu/reference-genomes/headers2/GCF_000160035.2_ASM16003v2_genomic.fna.gz') as f:
    GCF_000160035 = f.read().splitlines()
with open('/gpfs/home/znb17pxu/reference-genomes/headers2/GCF_000160055.1_ASM16005v1_genomic.fna.gz') as f:
    GCF_000160055 = f.read().splitlines()
with open('/gpfs/home/znb17pxu/reference-genomes/headers2/GCF_000160075.2_ASM16007v2_genomic.fna.gz') as f:
    GCF_000160075 = f.read().splitlines()
with open('/gpfs/home/znb17pxu/reference-genomes/headers2/GCF_000160435.1_ASM16043v1_genomic.fna.gz') as f:
    GCF_000160435 = f.read().splitlines()
with open('/gpfs/home/znb17pxu/reference-genomes/headers2/GCF_000162015.1_ASM16201v1_genomic.fna.gz') as f:
    GCF_000162015 = f.read().splitlines()
with open('/gpfs/home/znb17pxu/reference-genomes/headers2/GCF_000163475.1_ASM16347v1_genomic.fna.gz') as f:
    GCF_000163475 = f.read().splitlines()
with open('/gpfs/home/znb17pxu/reference-genomes/headers2/GCF_000164675.2_ASM16467v2_genomic.fna.gz') as f:
    GCF_000164675 = f.read().splitlines()
with open('/gpfs/home/znb17pxu/reference-genomes/headers2/GCF_000164695.2_ASM16469v2_genomic.fna.gz') as f:
    GCF_000164695 = f.read().splitlines()
with open('/gpfs/home/znb17pxu/reference-genomes/headers2/GCF_000173915.1_ASM17391v1_genomic.fna.gz') as f:
    GCF_000173915 = f.read().splitlines()
with open('/gpfs/home/znb17pxu/reference-genomes/headers2/GCF_000174175.1_ASM17417v1_genomic.fna.gz') as f:
    GCF_000174175 = f.read().splitlines()
with open('/gpfs/home/znb17pxu/reference-genomes/headers2/GCF_000175635.1_ASM17563v1_genomic.fna.gz') as f:
    GCF_000175635 = f.read().splitlines()
with open('/gpfs/home/znb17pxu/reference-genomes/headers2/GCF_000177075.1_ASM17707v1_genomic.fna.gz') as f:
    GCF_000177075 = f.read().splitlines()
with open('/gpfs/home/znb17pxu/reference-genomes/headers2/GCF_000177375.1_ASM17737v1_genomic.fna.gz') as f:
    GCF_000177375 = f.read().splitlines()
with open('/gpfs/home/znb17pxu/reference-genomes/headers2/GCF_000186165.1_Neis_muco_C102_V1_genomic.fna.gz') as f:
    GCF_000186165 = f.read().splitlines()
with open('/gpfs/home/znb17pxu/reference-genomes/headers2/GCF_000195995.1_ASM19599v1_genomic.fna.gz') as f:
    GCF_000195995 = f.read().splitlines()
with open('/gpfs/home/znb17pxu/reference-genomes/headers2/GCF_000196035.1_ASM19603v1_genomic.fna.gz') as f:
    GCF_000196035 = f.read().splitlines()
with open('/gpfs/home/znb17pxu/reference-genomes/headers2/GCF_000253395.1_ASM25339v1_genomic.fna.gz') as f:
    GCF_000253395 = f.read().splitlines()
with open('/gpfs/home/znb17pxu/reference-genomes/headers2/GCF_000376645.1_ASM37664v1_genomic.fna.gz') as f:
    GCF_000376645 = f.read().splitlines()
with open('/gpfs/home/znb17pxu/reference-genomes/headers2/GCF_000412995.1_Trep_vinc_F0403_V1_genomic.fna.gz') as f:
    GCF_000412995 = f.read().splitlines()
with open('/gpfs/home/znb17pxu/reference-genomes/headers2/GCF_000516535.1_ASM51653v1_genomic.fna.gz') as f:
    GCF_000516535 = f.read().splitlines()
with open('/gpfs/home/znb17pxu/reference-genomes/headers2/GCF_000818035.1_ASM81803v1_genomic.fna.gz') as f:
    GCF_000818035 = f.read().splitlines()
with open('/gpfs/home/znb17pxu/reference-genomes/headers2/GRCh38.fasta.gz') as f:
    GRCh38 = f.read().splitlines()
with open('/gpfs/home/znb17pxu/reference-genomes/headers2/JRMW01.1.fsa_nt.fna.gz') as f:
    JRMW01 = f.read().splitlines()
with open('/gpfs/home/znb17pxu/reference-genomes/headers2/LOQF01.1.fsa_nt.fna.gz') as f:
    LOQF01 = f.read().splitlines()
with open('/gpfs/home/znb17pxu/reference-genomes/headers2/LSDG01.1.fsa_nt.fna.gz') as f:
    LSDG01 = f.read().splitlines()
with open('/gpfs/home/znb17pxu/reference-genomes/headers2/NC_000908.2.fsa_nt.fna.gz') as f:
    NC_000908 = f.read().splitlines()
with open('/gpfs/home/znb17pxu/reference-genomes/headers2/NC_004368.1.fsa_nt.fna.gz') as f:
    NC_004368 = f.read().splitlines()
with open('/gpfs/home/znb17pxu/reference-genomes/headers2/NC_013171.1.fsa_nt.fna.gz') as f:
    NC_013171 = f.read().splitlines()
with open('/gpfs/home/znb17pxu/reference-genomes/headers2/NC_014246.1.fsa_nt.fna.gz') as f:
    NC_014246 = f.read().splitlines()
with open('/gpfs/home/znb17pxu/reference-genomes/headers2/NC_017333.1.fsa_nt.fna.gz') as f:
    NC_017333 = f.read().splitlines()
with open('/gpfs/home/znb17pxu/reference-genomes/headers2/NC_022239.1.fsa_nt.fna.gz') as f:
    NC_022239 = f.read().splitlines()
with open('/gpfs/home/znb17pxu/reference-genomes/headers2/NZ_CM000955.1.fsa_nt.fna.gz') as f:
    NZ_CM000955 = f.read().splitlines()
with open('/gpfs/home/znb17pxu/reference-genomes/headers2/NZ_CP012195.1.fsa_nt.fna.gz') as f:
    NZ_CP012195 = f.read().splitlines()


#declare headers and forma  list of headers in the input file
#may struggle with 300m reads, give it a test and see how it does - or build read counting into loop
input_headers = []

if (infile[-3:]) == ".gz":
    with gzip.open(infile, "rt") as gzipfile:
        for s in SeqIO.parse(gzipfile, format):
            input_headers.append(s.id)
else:
    for s in SeqIO.parse(infile, format):
        input_headers.append(s.id)

#for each term in input headers, get rid of the _read_ bit and retain only the first information
input_headers2 = []
for term in input_headers:
    input_headers2.append(term.split("_read_")[0])
input_headers = input_headers2




#loop through input headers and search for its responsible file
progressindicator = 0

for header in input_headers:
    progressindicator = progressindicator + 1
    if progressindicator % 1000000 == 0:
        progress_string = str(progressindicator)
        print(progress_string + " reference sequences processed") #print progress reports every 100000 reads
    
    if header in ABXA01:
        ABXA01_count = ABXA01_count + 1
        continue
    if header in ABYP01:
        ABYP01_count = ABYP01_count + 1
        continue
    if header in ABYQ02:
        ABYQ02_count = ABYQ02_count + 1
        continue
    if header in ACDD01:
        ACDD01_count = ACDD01_count + 1
        continue
    if header in AEEH01:
        AEEH01_count = AEEH01_count + 1
        continue
    if header in AENP01:
        AENP01_count = AENP01_count + 1
        continue
    if header in AEXM01:
        AEXM01_count = AEXM01_count + 1
        continue
    if header in AGWL01:
        AGWL01_count = AGWL01_count + 1
        continue
    if header in AGWP01:
        AGWP01_count = AGWP01_count + 1
        continue
    if header in AGWQ01:
        AGWQ01_count = AGWQ01_count + 1
        continue
    if header in AGZR01:
        AGZR01_count = AGZR01_count + 1
        continue
    if header in AJVZ01:
        AJVZ01_count = AJVZ01_count + 1
        continue
    if header in AQVC01:
        AQVC01_count = AQVC01_count + 1
        continue
    if header in AQWR01:
        AQWR01_count = AQWR01_count + 1
        continue
    if header in ARGD01:
        ARGD01_count = ARGD01_count + 1
        continue
    if header in ATBY01:
        ATBY01_count = ATBY01_count + 1
        continue
    if header in ATIO01:
        ATIO01_count = ATIO01_count + 1
        continue
    if header in ATUF01:
        ATUF01_count = ATUF01_count + 1
        continue
    if header in ATUY01:
        ATUY01_count = ATUY01_count + 1
        continue
    if header in AUIB01:
        AUIB01_count = AUIB01_count + 1
        continue
    if header in AUME01:
        AUME01_count = AUME01_count + 1
        continue
    if header in AWXB01:
        AWXB01_count = AWXB01_count + 1
        continue
    if header in AZIS01:
        AZIS01_count = AZIS01_count + 1
        continue
    if header in BAIS01:
        BAIS01_count = BAIS01_count + 1
        continue
    if header in CBQQ01:
        CBQQ01_count = CBQQ01_count + 1
        continue
    if header in CP008802:
        CP008802_count = CP008802_count + 1
        continue
    if header in GCF_000005845:
        GCF_000005845_count = GCF_000005845_count + 1
        continue
    if header in GCF_000007325:
        GCF_000007325_count = GCF_000007325_count + 1
        continue
    if header in GCF_000007645:
        GCF_000007645_count = GCF_000007645_count + 1
        continue
    if header in GCF_000007785:
        GCF_000007785_count = GCF_000007785_count + 1
        continue
    if header in GCF_000008345:
        GCF_000008345_count = GCF_000008345_count + 1
        continue
    if header in GCF_000008525:
        GCF_000008525_count = GCF_000008525_count + 1
        continue
    if header in GCF_000009925:
        GCF_000009925_count = GCF_000009925_count + 1
        continue
    if header in GCF_000021265:
        GCF_000021265_count = GCF_000021265_count + 1
        continue
    if header in GCF_000024565:
        GCF_000024565_count = GCF_000024565_count + 1
        continue
    if header in GCF_000024945:
        GCF_000024945_count = GCF_000024945_count + 1
        continue
    if header in GCF_000027165:
        GCF_000027165_count = GCF_000027165_count + 1
        continue
    if header in GCF_000027305:
        GCF_000027305_count = GCF_000027305_count + 1
        continue
    if header in GCF_000092265:
        GCF_000092265_count = GCF_000092265_count + 1
        continue
    if header in GCF_000153885:
        GCF_000153885_count = GCF_000153885_count + 1
        continue
    if header in GCF_000153925:
        GCF_000153925_count = GCF_000153925_count + 1
        continue
    if header in GCF_000154805:
        GCF_000154805_count = GCF_000154805_count + 1
        continue
    if header in GCF_000156675:
        GCF_000156675_count = GCF_000156675_count + 1
        continue
    if header in GCF_000157995:
        GCF_000157995_count = GCF_000157995_count + 1
        continue
    if header in GCF_000159115:
        GCF_000159115_count = GCF_000159115_count + 1
        continue
    if header in GCF_000160035:
        GCF_000160035_count = GCF_000160035_count + 1
        continue
    if header in GCF_000160055:
        GCF_000160055_count = GCF_000160055_count + 1
        continue
    if header in GCF_000160075:
        GCF_000160075_count = GCF_000160075_count + 1
        continue
    if header in GCF_000160435:
        GCF_000160435_count = GCF_000160435_count + 1
        continue
    if header in GCF_000162015:
        GCF_000162015_count = GCF_000162015_count + 1
        continue
    if header in GCF_000163475:
        GCF_000163475_count = GCF_000163475_count + 1
        continue
    if header in GCF_000164675:
        GCF_000164675_count = GCF_000164675_count + 1
        continue
    if header in GCF_000164695:
        GCF_000164695_count = GCF_000164695_count + 1
        continue
    if header in GCF_000173915:
        GCF_000173915_count = GCF_000173915_count + 1
        continue
    if header in GCF_000174175:
        GCF_000174175_count = GCF_000174175_count + 1
        continue
    if header in GCF_000175635:
        GCF_000175635_count = GCF_000175635_count + 1
        continue
    if header in GCF_000177075:
        GCF_000177075_count = GCF_000177075_count + 1
        continue
    if header in GCF_000177375:
        GCF_000177375_count = GCF_000177375_count + 1
        continue
    if header in GCF_000186165:
        GCF_000186165_count = GCF_000186165_count + 1
        continue
    if header in GCF_000195995:
        GCF_000195995_count = GCF_000195995_count + 1
        continue
    if header in GCF_000196035:
        GCF_000196035_count = GCF_000196035_count + 1
        continue
    if header in GCF_000253395:
        GCF_000253395_count = GCF_000253395_count + 1
        continue
    if header in GCF_000376645:
        GCF_000376645_count = GCF_000376645_count + 1
        continue
    if header in GCF_000412995:
        GCF_000412995_count = GCF_000412995_count + 1
        continue
    if header in GCF_000516535:
        GCF_000516535_count = GCF_000516535_count + 1
        continue
    if header in GCF_000818035:
        GCF_000818035_count = GCF_000818035_count + 1
        continue
    if header in GRCh38:
        GRCh38_count = GRCh38_count + 1
        continue
    if header in JRMW01:
        JRMW01_count = JRMW01_count + 1
        continue
    if header in LOQF01:
        LOQF01_count = LOQF01_count + 1
        continue
    if header in LSDG01:
        LSDG01_count = LSDG01_count + 1
        continue
    if header in NC_000908:
        NC_000908_count = NC_000908_count + 1
        continue
    if header in NC_004368:
        NC_004368_count = NC_004368_count + 1
        continue
    if header in NC_013171:
        NC_013171_count = NC_013171_count + 1
        continue
    if header in NC_014246:
        NC_014246_count = NC_014246_count + 1
        continue
    if header in NC_017333:
        NC_017333_count = NC_017333_count + 1
        continue
    if header in NC_022239:
        NC_022239_count = NC_022239_count + 1
        continue
    if header in NZ_CM000955:
        NZ_CM000955_count = NZ_CM000955_count + 1
        continue
    if header in NZ_CP012195:
        NZ_CP012195_count = NZ_CP012195_count + 1
        continue
    if "NC_007605" in header:
        NC_007605_count = NC_007605_count + 1
        continue
    if "NC_001526" in header:
        NC_001526_count = NC_001526_count + 1
        continue
    if "NC_022518" in header:
        NC_022518_count = NC_022518_count + 1
        continue
    if "NC_000898" in header:
        NC_000898_count = NC_000898_count + 1
        continue
    if "NC_014081" in header:
        NC_014081_count = NC_014081_count + 1
        continue
    if "NC_001405" in header:
        NC_001405_count = NC_001405_count + 1
        continue
    if "NC_003977" in header:
        NC_003977_count = NC_003977_count + 1
        continue
    if "NC_001802" in header:
        NC_001802_count = NC_001802_count + 1
        continue
    if "NC_002204" in header:
        NC_002204_count = NC_002204_count + 1
        continue
    if "NC_001357" in header:
        NC_001357_count = NC_001357_count + 1
        continue


# Announce that measurement is complete and that writing to file is commencing
print("Measurements complete, %s reads total, writing to file" %progressindicator)

writetofile = []

#print all values over 1 to file     ------ FICX FILE NAMES IN STRING = ("FILENAME") 
if ABXA01_count > 0:
    string = ("ABXA01.1.fsa_nt.fna\t" + str(ABXA01_count) + "\n")
    writetofile.append(string)
    string = ""
if ABYP01_count > 0:
    string = ("ABYP01.1.fsa_nt.fna\t" + str(ABYP01_count) + "\n")
    writetofile.append(string)
    string = ""
if ABYQ02_count > 0:
    string = ("ABYQ02.1.fsa_nt.fna\t" + str(ABYQ02_count) + "\n")
    writetofile.append(string)
    string = ""
if ACDD01_count > 0:
    string = ("ACDD01.1.fsa_nt.fna\t" + str(ACDD01_count) + "\n")
    writetofile.append(string)
    string = ""
if AEEH01_count > 0:
    string = ("AEEH01.1.fsa_nt.fna\t" + str(AEEH01_count) + "\n")
    writetofile.append(string)
    string = ""
if AENP01_count > 0:
    string = ("AENP01.1.fsa_nt.fna\t" + str(AENP01_count) + "\n")
    writetofile.append(string)
    string = ""
if AEXM01_count > 0:
    string = ("AEXM01.1.fsa_nt.fna\t" + str(AEXM01_count) + "\n")
    writetofile.append(string)
    string = ""
if AGWL01_count > 0:
    string = ("AGWL01.1.fsa_nt.fna\t" + str(AGWL01_count) + "\n")
    writetofile.append(string)
    string = ""
if AGWP01_count > 0:
    string = ("AGWP01.1.fsa_nt.fna\t" + str(AGWP01_count) + "\n")
    writetofile.append(string)
    string = ""
if AGWQ01_count > 0:
    string = ("AGWQ01.1.fsa_nt.fna\t" + str(AGWQ01_count) + "\n")
    writetofile.append(string)
    string = ""
if AGZR01_count > 0:
    string = ("AGZR01.1.fsa_nt.fna\t" + str(AGZR01_count) + "\n")
    writetofile.append(string)
    string = ""
if AJVZ01_count > 0:
    string = ("AJVZ01.1.fsa_nt.fna\t" + str(AJVZ01_count) + "\n")
    writetofile.append(string)
    string = ""
if AQVC01_count > 0:
    string = ("AQVC01.1.fsa_nt.fna\t" + str(AQVC01_count) + "\n")
    writetofile.append(string)
    string = ""
if AQWR01_count > 0:
    string = ("AQWR01.1.fsa_nt.fna\t" + str(AQWR01_count) + "\n")
    writetofile.append(string)
    string = ""
if ARGD01_count > 0:
    string = ("ARGD01.1.fsa_nt.fna\t" + str(ARGD01_count) + "\n")
    writetofile.append(string)
    string = ""
if ATBY01_count > 0:
    string = ("ATBY01.1.fsa_nt.fna\t" + str(ATBY01_count) + "\n")
    writetofile.append(string)
    string = ""
if ATIO01_count > 0:
    string = ("ATIO01.1.fsa_nt.fna\t" + str(ATIO01_count) + "\n")
    writetofile.append(string)
    string = ""
if ATUF01_count > 0:
    string = ("ATUF01.1.fsa_nt.fna\t" + str(ATUF01_count) + "\n")
    writetofile.append(string)
    string = ""
if ATUY01_count > 0:
    string = ("ATUY01.1.fsa_nt.fna\t" + str(ATUY01_count) + "\n")
    writetofile.append(string)
    string = ""
if AUIB01_count > 0:
    string = ("AUIB01.1.fsa_nt.fna\t" + str(AUIB01_count) + "\n")
    writetofile.append(string)
    string = ""
if AUME01_count > 0:
    string = ("AUME01.1.fsa_nt.fna\t" + str(AUME01_count) + "\n")
    writetofile.append(string)
    string = ""
if AWXB01_count > 0:
    string = ("AWXB01.1.fsa_nt.fna\t" + str(AWXB01_count) + "\n")
    writetofile.append(string)
    string = ""
if AZIS01_count > 0:
    string = ("AZIS01.1.fsa_nt.fna\t" + str(AZIS01_count) + "\n")
    writetofile.append(string)
    string = ""
if BAIS01_count > 0:
    string = ("BAIS01.1.fsa_nt.fna\t" + str(BAIS01_count) + "\n")
    writetofile.append(string)
    string = ""
if CBQQ01_count > 0:
    string = ("CBQQ01.1.fsa_nt.fna\t" + str(CBQQ01_count) + "\n")
    writetofile.append(string)
    string = ""
if CP008802_count > 0:
    string = ("CP008802.1.fsa_nt.fna\t" + str(CP008802_count) + "\n")
    writetofile.append(string)
    string = ""
if GCF_000005845_count > 0:
    string = ("GCF_000005845.2_ASM584v2_genomic.fna\t" + str(GCF_000005845_count) + "\n")
    writetofile.append(string)
    string = ""
if GCF_000007325_count > 0:
    string = ("GCF_000007325.1_ASM732v1_genomic.fna\t" + str(GCF_000007325_count) + "\n")
    writetofile.append(string)
    string = ""
if GCF_000007645_count > 0:
    string = ("GCF_000007645.1_ASM764v1_genomic.fna\t" + str(GCF_000007645_count) + "\n")
    writetofile.append(string)
    string = ""
if GCF_000007785_count > 0:
    string = ("GCF_000007785.1_ASM778v1_genomic.fna\t" + str(GCF_000007785_count) + "\n")
    writetofile.append(string)
    string = ""
if GCF_000008345_count > 0:
    string = ("GCF_000008345.1_ASM834v1_genomic.fna\t" + str(GCF_000008345_count) + "\n")
    writetofile.append(string)
    string = ""
if GCF_000008525_count > 0:
    string = ("GCF_000008525.1_ASM852v1_genomic.fna\t" + str(GCF_000008525_count) + "\n")
    writetofile.append(string)
    string = ""
if GCF_000009925_count > 0:
    string = ("GCF_000009925.1_ASM992v1_genomic.fna\t" + str(GCF_000009925_count) + "\n")
    writetofile.append(string)
    string = ""
if GCF_000021265_count > 0:
    string = ("GCF_000021265.1_ASM2126v1_genomic.fna\t" + str(GCF_000021265_count) + "\n")
    writetofile.append(string)
    string = ""
if GCF_000024565_count > 0:
    string = ("GCF_000024565.1_ASM2456v1_genomic.fna\t" + str(GCF_000024565_count) + "\n")
    writetofile.append(string)
    string = ""
if GCF_000024945_count > 0:
    string = ("GCF_000024945.1_ASM2494v1_genomic.fna\t" + str(GCF_000024945_count) + "\n")
    writetofile.append(string)
    string = ""
if GCF_000027165_count > 0:
    string = ("GCF_000027165.1_ASM2716v1_genomic.fna\t" + str(GCF_000027165_count) + "\n")
    writetofile.append(string)
    string = ""
if GCF_000027305_count > 0:
    string = ("GCF_000027305.1_ASM2730v1_genomic.fna\t" + str(GCF_000027305_count) + "\n")
    writetofile.append(string)
    string = ""
if GCF_000092265_count > 0:
    string = ("GCF_000092265.1_ASM9226v1_genomic.fna\t" + str(GCF_000092265_count) + "\n")
    writetofile.append(string)
    string = ""
if GCF_000153885_count > 0:
    string = ("GCF_000153885.1_ASM15388v1_genomic.fna\t" + str(GCF_000153885_count) + "\n")
    writetofile.append(string)
    string = ""
if GCF_000153925_count > 0:
    string = ("GCF_000153925.1_ASM15392v1_genomic.fna\t" + str(GCF_000153925_count) + "\n")
    writetofile.append(string)
    string = ""
if GCF_000154805_count > 0:
    string = ("GCF_000154805.1_ASM15480v1_genomic.fna\t" + str(GCF_000154805_count) + "\n")
    writetofile.append(string)
    string = ""
if GCF_000156675_count > 0:
    string = ("GCF_000156675.1_ASM15667v1_genomic.fna\t" + str(GCF_000156675_count) + "\n")
    writetofile.append(string)
    string = ""
if GCF_000157995_count > 0:
    string = ("GCF_000157995.1_ASM15799v1_genomic.fna\t" + str(GCF_000157995_count) + "\n")
    writetofile.append(string)
    string = ""
if GCF_000159115_count > 0:
    string = ("GCF_000159115.1_ASM15911v1_genomic.fna\t" + str(GCF_000159115_count) + "\n")
    writetofile.append(string)
    string = ""
if GCF_000160035_count > 0:
    string = ("GCF_000160035.2_ASM16003v2_genomic.fna\t" + str(GCF_000160035_count) + "\n")
    writetofile.append(string)
    string = ""
if GCF_000160055_count > 0:
    string = ("GCF_000160055.1_ASM16005v1_genomic.fna\t" + str(GCF_000160055_count) + "\n")
    writetofile.append(string)
    string = ""
if GCF_000160075_count > 0:
    string = ("GCF_000160075.2_ASM16007v2_genomic.fna\t" + str(GCF_000160075_count) + "\n")
    writetofile.append(string)
    string = ""
if GCF_000160435_count > 0:
    string = ("GCF_000160435.1_ASM16043v1_genomic.fna\t" + str(GCF_000160435_count) + "\n")
    writetofile.append(string)
    string = ""
if GCF_000162015_count > 0:
    string = ("GCF_000162015.1_ASM16201v1_genomic.fna\t" + str(GCF_000162015_count) + "\n")
    writetofile.append(string)
    string = ""
if GCF_000163475_count > 0:
    string = ("GCF_000163475.1_ASM16347v1_genomic.fna\t" + str(GCF_000163475_count) + "\n")
    writetofile.append(string)
    string = ""
if GCF_000164675_count > 0:
    string = ("GCF_000164675.2_ASM16467v2_genomic.fna\t" + str(GCF_000164675_count) + "\n")
    writetofile.append(string)
    string = ""
if GCF_000164695_count > 0:
    string = ("GCF_000164695.2_ASM16469v2_genomic.fna\t" + str(GCF_000164695_count) + "\n")
    writetofile.append(string)
    string = ""
if GCF_000173915_count > 0:
    string = ("GCF_000173915.1_ASM17391v1_genomic.fna\t" + str(GCF_000173915_count) + "\n")
    writetofile.append(string)
    string = ""
if GCF_000174175_count > 0:
    string = ("GCF_000174175.1_ASM17417v1_genomic.fna\t" + str(GCF_000174175_count) + "\n")
    writetofile.append(string)
    string = ""
if GCF_000175635_count > 0:
    string = ("GCF_000175635.1_ASM17563v1_genomic.fna\t" + str(GCF_000175635_count) + "\n")
    writetofile.append(string)
    string = ""
if GCF_000177075_count > 0:
    string = ("GCF_000177075.1_ASM17707v1_genomic.fna\t" + str(GCF_000177075_count) + "\n")
    writetofile.append(string)
    string = ""
if GCF_000177375_count > 0:
    string = ("GCF_000177375.1_ASM17737v1_genomic.fna\t" + str(GCF_000177375_count) + "\n")
    writetofile.append(string)
    string = ""
if GCF_000186165_count > 0:
    string = ("GCF_000186165.1_Neis_muco_C102_V1_genomic.fna\t" + str(GCF_000186165_count) + "\n")
    writetofile.append(string)
    string = ""
if GCF_000195995_count > 0:
    string = ("GCF_000195995.1_ASM19599v1_genomic.fna\t" + str(GCF_000195995_count) + "\n")
    writetofile.append(string)
    string = ""
if GCF_000196035_count > 0:
    string = ("GCF_000196035.1_ASM19603v1_genomic.fna\t" + str(GCF_000196035_count) + "\n")
    writetofile.append(string)
    string = ""
if GCF_000253395_count > 0:
    string = ("GCF_000253395.1_ASM25339v1_genomic.fna\t" + str(GCF_000253395_count) + "\n")
    writetofile.append(string)
    string = ""
if GCF_000376645_count > 0:
    string = ("GCF_000376645.1_ASM37664v1_genomic.fna\t" + str(GCF_000376645_count) + "\n")
    writetofile.append(string)
    string = ""
if GCF_000412995_count > 0:
    string = ("GCF_000412995.1_Trep_vinc_F0403_V1_genomic.fna\t" + str(GCF_000412995_count) + "\n")
    writetofile.append(string)
    string = ""
if GCF_000516535_count > 0:
    string = ("GCF_000516535.1_ASM51653v1_genomic.fna\t" + str(GCF_000516535_count) + "\n")
    writetofile.append(string)
    string = ""
if GCF_000818035_count > 0:
    string = ("GCF_000818035.1_ASM81803v1_genomic.fna\t" + str(GCF_000818035_count) + "\n")
    writetofile.append(string)
    string = ""
if GRCh38_count > 0:
    string = ("GRCh38.fasta\t" + str(GRCh38_count) + "\n")
    writetofile.append(string)
    string = ""
if JRMW01_count > 0:
    string = ("JRMW01.1.fsa_nt.fna\t" + str(JRMW01_count) + "\n")
    writetofile.append(string)
    string = ""
if LOQF01_count > 0:
    string = ("LOQF01.1.fsa_nt.fna\t" + str(LOQF01_count) + "\n")
    writetofile.append(string)
    string = ""
if LSDG01_count > 0:
    string = ("LSDG01.1.fsa_nt.fna\t" + str(LSDG01_count) + "\n")
    writetofile.append(string)
    string = ""
if NC_000908_count > 0:
    string = ("NC_000908.2.fsa_nt.fna\t" + str(NC_000908_count) + "\n")
    writetofile.append(string)
    string = ""
if NC_004368_count > 0:
    string = ("NC_004368.1.fsa_nt.fna\t" + str(NC_004368_count) + "\n")
    writetofile.append(string)
    string = ""
if NC_013171_count > 0:
    string = ("NC_013171.1.fsa_nt.fna\t" + str(NC_013171_count) + "\n")
    writetofile.append(string)
    string = ""
if NC_014246_count > 0:
    string = ("NC_014246.1.fsa_nt.fna\t" + str(NC_014246_count) + "\n")
    writetofile.append(string)
    string = ""
if NC_017333_count > 0:
    string = ("NC_017333.1.fsa_nt.fna\t" + str(NC_017333_count) + "\n")
    writetofile.append(string)
    string = ""
if NC_022239_count > 0:
    string = ("NC_022239.1.fsa_nt.fna\t" + str(NC_022239_count) + "\n")
    writetofile.append(string)
    string = ""
if NZ_CM000955_count > 0:
    string = ("NZ_CM000955.1.fsa_nt.fna\t" + str(NZ_CM000955_count) + "\n")
    writetofile.append(string)
    string = ""
if NZ_CP012195_count > 0:
    string = ("NZ_CP012195.1.fsa_nt.fna\t" + str(NZ_CP012195_count) + "\n")
    writetofile.append(string)
    string = ""
if NC_007605_count > 0:
    string = ("NC_007605.fna\t" + str(NC_007605_count) + "\n")
    writetofile.append(string)
    string = ""
if NC_001526_count > 0:
    string = ("NC_001526.fna\t" + str(NC_001526_count) + "\n")
    writetofile.append(string)
    string = ""
if NC_022518_count > 0:
    string = ("NC_022518.fna\t" + str(NC_022518_count) + "\n")
    writetofile.append(string)
    string = ""
if NC_000898_count > 0:
    string = ("NC_000898.fna\t" + str(NC_000898_count) + "\n")
    writetofile.append(string)
    string = ""
if NC_014081_count > 0:
    string = ("NC_014081.fna\t" + str(NC_014081_count) + "\n")
    writetofile.append(string)
    string = ""
if NC_001405_count > 0:
    string = ("NC_001405.fna\t" + str(NC_001405_count) + "\n")
    writetofile.append(string)
    string = ""
if NC_003977_count > 0:
    string = ("NC_003977.fna\t" + str(NC_003977_count) + "\n")
    writetofile.append(string)
    string = ""
if NC_001802_count > 0:
    string = ("NC_001802.fna\t" + str(NC_001802_count) + "\n")
    writetofile.append(string)
    string = ""
if NC_002204_count > 0:
    string = ("NC_002204.fna\t" + str(NC_002204_count) + "\n")
    writetofile.append(string)
    string = ""
if NC_001357_count > 0:
    string = ("NC_001357.fna\t" + str(NC_001357_count) + "\n")
    writetofile.append(string)
    string = ""

#write to file
with open(newfilename, "a") as newfile:
    for term in writetofile:
        newfile.write(term)   #maybe do str(term)
