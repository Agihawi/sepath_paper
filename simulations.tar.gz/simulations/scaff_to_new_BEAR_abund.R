#This script will redistribute an abundance proportionally among scaffholds in a fastq file and form an abundance file suitable for use with a multi-FASTA program 
#Usage - have this script in the directory containing the abundance file (BEAR_abund) is called here, which is a tab delimited file contiaining the fasta filename, and the abundance where the total abundance = 1
#         Also have in this directory, scaffhold counts that contain the relative length of scaffholds in a fastq file

# Ultimate file produced is BEAR_abundance_file which will have FASTA headers and proportions 
# use in R/3.4.0/gcc-mellanox



#library(tidyverse)
library(dplyr)
library(readr)



filenames <- c("GRCh38.fasta", "ABXA01.1.fsa_nt.fna", "ABYP01.1.fsa_nt.fna", "ABYQ02.1.fsa_nt.fna", "ACDD01.1.fsa_nt.fna", "AEEH01.1.fsa_nt.fna", "AENP01.1.fsa_nt.fna", "AEXM01.1.fsa_nt.fna", "AGWL01.1.fsa_nt.fna", "AGWP01.1.fsa_nt.fna", "AGWQ01.1.fsa_nt.fna", "AGZR01.1.fsa_nt.fna", "AJVZ01.1.fsa_nt.fna", "AQVC01.1.fsa_nt.fna", "AQWR01.1.fsa_nt.fna", "ARGD01.1.fsa_nt.fna", "ATBY01.1.fsa_nt.fna", "ATIO01.1.fsa_nt.fna", "ATUF01.1.fsa_nt.fna", "ATUY01.1.fsa_nt.fna", "AUIB01.1.fsa_nt.fna", "AUME01.1.fsa_nt.fna", "AWXB01.1.fsa_nt.fna", "AZIS01.1.fsa_nt.fna", "BAIS01.1.fsa_nt.fna", "CBQQ01.1.fsa_nt.fna", "CP008802.1.fsa_nt.fna", "GCF_000005845.2_ASM584v2_genomic.fna", "GCF_000007325.1_ASM732v1_genomic.fna", "GCF_000007645.1_ASM764v1_genomic.fna", "GCF_000007785.1_ASM778v1_genomic.fna", "GCF_000008345.1_ASM834v1_genomic.fna", "GCF_000008525.1_ASM852v1_genomic.fna", "GCF_000009925.1_ASM992v1_genomic.fna", "GCF_000021265.1_ASM2126v1_genomic.fna", "GCF_000024565.1_ASM2456v1_genomic.fna", "GCF_000024945.1_ASM2494v1_genomic.fna", "GCF_000027165.1_ASM2716v1_genomic.fna", "GCF_000027305.1_ASM2730v1_genomic.fna", "GCF_000092265.1_ASM9226v1_genomic.fna", "GCF_000153885.1_ASM15388v1_genomic.fna", "GCF_000153925.1_ASM15392v1_genomic.fna", "GCF_000154805.1_ASM15480v1_genomic.fna", "GCF_000156675.1_ASM15667v1_genomic.fna", "GCF_000157995.1_ASM15799v1_genomic.fna", "GCF_000159115.1_ASM15911v1_genomic.fna", "GCF_000160035.2_ASM16003v2_genomic.fna", "GCF_000160055.1_ASM16005v1_genomic.fna", "GCF_000160075.2_ASM16007v2_genomic.fna", "GCF_000160435.1_ASM16043v1_genomic.fna", "GCF_000162015.1_ASM16201v1_genomic.fna", "GCF_000163475.1_ASM16347v1_genomic.fna", "GCF_000164675.2_ASM16467v2_genomic.fna", "GCF_000164695.2_ASM16469v2_genomic.fna", "GCF_000173915.1_ASM17391v1_genomic.fna", "GCF_000174175.1_ASM17417v1_genomic.fna", "GCF_000175635.1_ASM17563v1_genomic.fna", "GCF_000177075.1_ASM17707v1_genomic.fna", "GCF_000177375.1_ASM17737v1_genomic.fna", "GCF_000186165.1_Neis_muco_C102_V1_genomic.fna", "GCF_000195995.1_ASM19599v1_genomic.fna", "GCF_000196035.1_ASM19603v1_genomic.fna", "GCF_000253395.1_ASM25339v1_genomic.fna", "GCF_000376645.1_ASM37664v1_genomic.fna", "GCF_000412995.1_Trep_vinc_F0403_V1_genomic.fna", "GCF_000516535.1_ASM51653v1_genomic.fna", "GCF_000818035.1_ASM81803v1_genomic.fna", "JRMW01.1.fsa_nt.fna", "LOQF01.1.fsa_nt.fna", "LSDG01.1.fsa_nt.fna", "NC_000908.2.fsa_nt.fna", "NC_004368.1.fsa_nt.fna", "NC_013171.1.fsa_nt.fna", "NC_014246.1.fsa_nt.fna", "NC_017333.1.fsa_nt.fna", "NC_022239.1.fsa_nt.fna", "NZ_CM000955.1.fsa_nt.fna", "NZ_CP012195.1.fsa_nt.fna")
scaff_count_names <- c("ABXA01.1.fsa_nt.fna_scaff_counts", "ABYP01.1.fsa_nt.fna_scaff_counts", "ABYQ02.1.fsa_nt.fna_scaff_counts", "ACDD01.1.fsa_nt.fna_scaff_counts", "AEEH01.1.fsa_nt.fna_scaff_counts", "AENP01.1.fsa_nt.fna_scaff_counts", "AEXM01.1.fsa_nt.fna_scaff_counts", "AGWL01.1.fsa_nt.fna_scaff_counts", "AGWP01.1.fsa_nt.fna_scaff_counts", "AGWQ01.1.fsa_nt.fna_scaff_counts", "AGZR01.1.fsa_nt.fna_scaff_counts", "AJVZ01.1.fsa_nt.fna_scaff_counts", "AQVC01.1.fsa_nt.fna_scaff_counts", "AQWR01.1.fsa_nt.fna_scaff_counts", "ARGD01.1.fsa_nt.fna_scaff_counts", "ATBY01.1.fsa_nt.fna_scaff_counts", "ATIO01.1.fsa_nt.fna_scaff_counts", "ATUF01.1.fsa_nt.fna_scaff_counts", "ATUY01.1.fsa_nt.fna_scaff_counts", "AUIB01.1.fsa_nt.fna_scaff_counts", "AUME01.1.fsa_nt.fna_scaff_counts", "AWXB01.1.fsa_nt.fna_scaff_counts", "AZIS01.1.fsa_nt.fna_scaff_counts", "BAIS01.1.fsa_nt.fna_scaff_counts", "CBQQ01.1.fsa_nt.fna_scaff_counts", "CP008802.1.fsa_nt.fna_scaff_counts", "GCF_000005845.2_ASM584v2_genomic.fna_scaff_counts", "GCF_000007325.1_ASM732v1_genomic.fna_scaff_counts", "GCF_000007645.1_ASM764v1_genomic.fna_scaff_counts", "GCF_000007785.1_ASM778v1_genomic.fna_scaff_counts", "GCF_000008345.1_ASM834v1_genomic.fna_scaff_counts", "GCF_000008525.1_ASM852v1_genomic.fna_scaff_counts", "GCF_000009925.1_ASM992v1_genomic.fna_scaff_counts", "GCF_000021265.1_ASM2126v1_genomic.fna_scaff_counts", "GCF_000024565.1_ASM2456v1_genomic.fna_scaff_counts", "GCF_000024945.1_ASM2494v1_genomic.fna_scaff_counts", "GCF_000027165.1_ASM2716v1_genomic.fna_scaff_counts", "GCF_000027305.1_ASM2730v1_genomic.fna_scaff_counts", "GCF_000092265.1_ASM9226v1_genomic.fna_scaff_counts", "GCF_000153885.1_ASM15388v1_genomic.fna_scaff_counts", "GCF_000153925.1_ASM15392v1_genomic.fna_scaff_counts", "GCF_000154805.1_ASM15480v1_genomic.fna_scaff_counts", "GCF_000156675.1_ASM15667v1_genomic.fna_scaff_counts", "GCF_000157995.1_ASM15799v1_genomic.fna_scaff_counts", "GCF_000159115.1_ASM15911v1_genomic.fna_scaff_counts", "GCF_000160035.2_ASM16003v2_genomic.fna_scaff_counts", "GCF_000160055.1_ASM16005v1_genomic.fna_scaff_counts", "GCF_000160075.2_ASM16007v2_genomic.fna_scaff_counts", "GCF_000160435.1_ASM16043v1_genomic.fna_scaff_counts", "GCF_000162015.1_ASM16201v1_genomic.fna_scaff_counts", "GCF_000163475.1_ASM16347v1_genomic.fna_scaff_counts", "GCF_000164675.2_ASM16467v2_genomic.fna_scaff_counts", "GCF_000164695.2_ASM16469v2_genomic.fna_scaff_counts", "GCF_000173915.1_ASM17391v1_genomic.fna_scaff_counts", "GCF_000174175.1_ASM17417v1_genomic.fna_scaff_counts", "GCF_000175635.1_ASM17563v1_genomic.fna_scaff_counts", "GCF_000177075.1_ASM17707v1_genomic.fna_scaff_counts", "GCF_000177375.1_ASM17737v1_genomic.fna_scaff_counts", "GCF_000186165.1_Neis_muco_C102_V1_genomic.fna_scaff_counts", "GCF_000195995.1_ASM19599v1_genomic.fna_scaff_counts", "GCF_000196035.1_ASM19603v1_genomic.fna_scaff_counts", "GCF_000253395.1_ASM25339v1_genomic.fna_scaff_counts", "GCF_000376645.1_ASM37664v1_genomic.fna_scaff_counts", "GCF_000412995.1_Trep_vinc_F0403_V1_genomic.fna_scaff_counts", "GCF_000516535.1_ASM51653v1_genomic.fna_scaff_counts", "GCF_000818035.1_ASM81803v1_genomic.fna_scaff_counts", "GRCh38_scaff_counts", "JRMW01.1.fsa_nt.fna_scaff_counts", "LOQF01.1.fsa_nt.fna_scaff_counts", "LSDG01.1.fsa_nt.fna_scaff_counts", "NC_000908.2.fsa_nt.fna_scaff_counts", "NC_004368.1.fsa_nt.fna_scaff_counts", "NC_013171.1.fsa_nt.fna_scaff_counts", "NC_014246.1.fsa_nt.fna_scaff_counts", "NC_017333.1.fsa_nt.fna_scaff_counts", "NC_022239.1.fsa_nt.fna_scaff_counts", "NZ_CM000955.1.fsa_nt.fna_scaff_counts", "NZ_CP012195.1.fsa_nt.fna_scaff_counts")

#load each scaffholding count file into a dataframe titled as the original filename
for (file in filenames){
  scaff_file <- read_tsv((paste0(file,"_scaff_counts")), col_names=FALSE)
  dfname <- paste0(file,"_df")
  assign(dfname, scaff_file)
  
}

#import BEAR abund file that is normalised bacterial proportions
BEAR_abund <- read_tsv(file = "abund.txt", col_names= FALSE)


#Cycle through each filename in the normalised abundancefile, form a list of files present in abundance file
for (item in BEAR_abund[1]){
  listoffilesinabundfile <- c(item)
}

#generate subset dataframe from bear abund containing the multipliers
for (filenamed in listoffilesinabundfile){
  dfname2 <- paste0(filenamed, "_multiplier_df")
  assign(dfname2, subset(BEAR_abund, X1==filenamed))
}  


#Now multiply each data frame by it's dataframe_multiplier_df to obtain the actual values for each scaffhold
for (filenamed in listoffilesinabundfile){
  multipliervalue <- as.numeric(get(paste0(filenamed,"_multiplier_df")))[2] #set multiplier value to relative abund.txt proportion
       #mutate the scaffhold dataframe by multiplying the second column by multiplier value, filter NA values that might be too small
  scaff_values <- (get(paste0(filenamed,"_df"))) %>% mutate(X2= X2 * multipliervalue) %>% filter(!is.na(X2))
  dfname3 <- (paste0(filenamed, "_scaff_values"))
  assign(dfname3, scaff_values) # set new df for each newly computed value that is filename_scaff_value
}


#form list of _scaff_value files
temp_df <- data.frame(X1 = listoffilesinabundfile, X2= NA) #arbitrarily turn something into a dataframe just to fit my code
for (filenamed in temp_df[1]){
  list_of_final_files <- c(paste0(filenamed, "_scaff_values"))
}


#form list of dataframes, and merge them all together
df_list <- lapply(list_of_final_files, get)
expanded_df <- do.call(rbind, df_list)

#Write the final table to an amazing single file
write.table(expanded_df, file = "BEAR_abundance_file", col.names=FALSE, row.names = FALSE, quote= FALSE, sep='\t')


