#convert filtered comp file to calculate relative abundance and spit out metadata such as shannon index

library(dplyr)
library(readr)

inputcomp <- read_tsv('filteredhumanless.comp', col_names=TRUE)

genomecounts <- read_tsv('~/bin/genomecounts.txt', col_names=FALSE)
colnames(genomecounts) <- c('Filename', 'Genome_length')


#merge input comp 
compandlengths <- (merge(inputcomp, genomecounts, by ='Filename', all.y=TRUE, all.x = TRUE))

#filter by NA for species that aren't there
compandlengths <- compandlengths %>% filter(!is.na(Species))

#calculate relative proportion by Number of reads / Genome length for each species
compandlengths <- compandlengths %>% mutate(relative_proportion = Number_of_Reads / Genome_length)

#calculate total relative proportion by summing up relative proportion column
totalrelativeproportion <- sum(compandlengths$relative_proportion)

#calculate relative abundances from relative proportions
compandlengths <- compandlengths %>% mutate(Relative_Abundance = relative_proportion / totalrelativeproportion)

# ----------now calculate shannon index

#calculate natural log of each relative abundance
compandlengths <- compandlengths %>% mutate(log_abundances = log(Relative_Abundance))

#calculate natural_log of relative abundance * relative abundance
compandlengths <- compandlengths %>% mutate(nl_ra = log_abundances * Relative_Abundance)

#calculate absolute value for shannon index by the sum of logabundance * relative_abundance
H <- abs(sum(compandlengths$nl_ra))

#Begin producing tasty metadata --- excluding human

total_ref_files_used <- paste0(nrow(compandlengths)) #number of rows in compandlengths
num_of_species <- paste0(length(unique(compandlengths$Species)))#unique number of species in compandlengths
min_reads <- paste0(min(compandlengths$Number_of_Reads))#minimum number of reads and species in compandlengths
min_abundance <- paste0(min(compandlengths$Relative_Abundance))#min abundance and species in comp and lengths
max_reads <- paste0(max(compandlengths$Number_of_Reads))#max reads and species in comp and lengths
max_abundance <- paste0(max(compandlengths$Relative_Abundance))#max abundance and species in comp and lengths

metadata <- data.frame(c("Shannon Index" , "Total Reference Files Used", "Number of Species", "Minimum Reads", "Minimum Abundance", "Maximum Reads", "Maximum Abundance" ),
                       c(H, total_ref_files_used, num_of_species, min_reads, min_abundance, max_reads, max_abundance) 
)

#save tasty metadata
write.table(metadata, file='metadata.txt', sep='\t', quote = FALSE, row.names = FALSE, col.names = FALSE)


#Make selection of comp file and save it
output_comp <- compandlengths %>% select(`NCBI-TaxID`, Kingdom, Phylum, Class, Order, Family, Genus, Species, Number_of_Reads, Relative_Abundance, 'Sub-Species', Filename)
write.table(output_comp, file="humanless_with_abundances.comp", sep='\t', quote = FALSE, row.names = FALSE, col.names = TRUE)


