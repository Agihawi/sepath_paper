#This script reads fastq counts and produces a humanless common metagenomics profile COMP file.


library(readr)
library(dplyr)

input_file <- commandArgs(trailingOnly = TRUE)

seqcount <- read_tsv(file = input_file, col_names = FALSE)
colnames(seqcount) <- c("Filename", "Number_of_Reads")

compfilenames <- read_tsv(file="~/bin/compfilenames", col_names=TRUE)

merged <- (merge(seqcount, compfilenames, by = 'Filename', all.y = TRUE, all.x = TRUE))

#form human read df
human_reads <- merged %>% filter(Filename == "GRCh38.fasta")

#filter human from merged
merged <- merged %>% filter(Filename != "GRCh38.fasta")

#added  line below to just write number of human reads to a "human_reads"
write.table(human_reads, file='human_reads', sep='\t', quote=FALSE, row.names=FALSE)

merged <- merged %>% filter(Number_of_Reads.x != "NA")


#Select columns for fastq format
compfile <- merged %>% select(`NCBI-TaxID`, Kingdom, Phylum, Class, Order, Family, Genus, Species, Number_of_Reads.x, Relative_Abundance, 'Sub-Species', Filename)
colnames(compfile) <- c('NCBI-TaxID', 'Kingdom', 'Phylum', 'Class', 'Order', 'Family', 'Genus', 'Species', 'Number_of_Reads', 'Relative_Abundance', 'Sub-Species', 'Filename')

write.table(compfile, file='filteredhumanless.comp', sep='\t', quote=FALSE, row.names=FALSE)


