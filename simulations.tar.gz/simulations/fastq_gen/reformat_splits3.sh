#!/bin/bash

#this script will remove line breaks from fasta files

cat *part-20.fasta | awk '!/^>/ { printf "%s", $0; n = "\n" } /^>/ { print n $0; n = "" } END { printf "%s", n }' > part_20.fasta; rm -f *part-20.fasta
cat *part-21.fasta | awk '!/^>/ { printf "%s", $0; n = "\n" } /^>/ { print n $0; n = "" } END { printf "%s", n }' > part_21.fasta; rm -f *part-21.fasta
cat *part-22.fasta | awk '!/^>/ { printf "%s", $0; n = "\n" } /^>/ { print n $0; n = "" } END { printf "%s", n }' > part_22.fasta; rm -f *part-22.fasta
cat *part-23.fasta | awk '!/^>/ { printf "%s", $0; n = "\n" } /^>/ { print n $0; n = "" } END { printf "%s", n }' > part_23.fasta; rm -f *part-23.fasta
cat *part-24.fasta | awk '!/^>/ { printf "%s", $0; n = "\n" } /^>/ { print n $0; n = "" } END { printf "%s", n }' > part_24.fasta; rm -f *part-24.fasta
cat *part-25.fasta | awk '!/^>/ { printf "%s", $0; n = "\n" } /^>/ { print n $0; n = "" } END { printf "%s", n }' > part_25.fasta; rm -f *part-25.fasta
cat *part-26.fasta | awk '!/^>/ { printf "%s", $0; n = "\n" } /^>/ { print n $0; n = "" } END { printf "%s", n }' > part_26.fasta; rm -f *part-26.fasta
cat *part-27.fasta | awk '!/^>/ { printf "%s", $0; n = "\n" } /^>/ { print n $0; n = "" } END { printf "%s", n }' > part_27.fasta; rm -f *part-27.fasta
cat *part-28.fasta | awk '!/^>/ { printf "%s", $0; n = "\n" } /^>/ { print n $0; n = "" } END { printf "%s", n }' > part_28.fasta; rm -f *part-28.fasta
cat *part-29.fasta | awk '!/^>/ { printf "%s", $0; n = "\n" } /^>/ { print n $0; n = "" } END { printf "%s", n }' > part_29.fasta; rm -f *part-29.fasta
cat *part-30.fasta | awk '!/^>/ { printf "%s", $0; n = "\n" } /^>/ { print n $0; n = "" } END { printf "%s", n }' > part_30.fasta; rm -f *part-30.fasta
