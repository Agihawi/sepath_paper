#!/gpfs/software/python/anaconda/4.2/anaconda2/bin/python

#This script will initiate file manipulation before splitting a fasta and initiating a fq generation snakemake

#call script filetoprocess

import os
import sys
import time
import subprocess
import glob

file = sys.argv[1]
filename = os.path.basename(file)
gzlessfile = filename[:-3]
finalfile = (gzlessfile[:-1] + "q.gz")
cancergenetics = "/gpfs/afm/cancergenetics/Abe/metagenomes_pcawg/"
#obtain first three number prefix for files
file_prefix = finalfile[0:3]

print("processing file: %s" %file)

#copy file to current directory, gunzip and split into multiple files
os.system("cp %s ./; gunzip %s; ../fasta-splitter.pl --line-length 0 --part-size 12500000 --measure count %s" %(file, filename, gzlessfile))

#remove original fasta file, then touch an empty one to delete later (just for tracking purposes and space saving)
os.system("rm -f %s; touch %s" %(gzlessfile, gzlessfile))

#remove pesky lines from each split fasta file - load 2 jobs to just speed it up a bit 
#os.system('bsub -J format_splits2 -q short-ib -M 4000 -R "rusage[mem=4000]" "reformat_splits.sh"')
#os.system('bsub -J format_splits2 -q short-ib -M 4000 -R "rusage[mem=4000]" "reformat_splits2.sh"')
#os.system('bsub -J format_splits2 -q short-ib -M 4000 -R "rusage[mem=4000]" "reformat_splits3.sh"')
#sleep for a while to prevent jobs being launched prematurely 480 = 8 mins
#time.sleep(480)

#launch snakemake to generate fastq files
#os.system('./generalrunner.sh')
#os.system('module add python/anaconda/4.2/3.5; source ~/dependencies; source ~/path-maker; bsub -J fq_snake -q long-eth -M 10000 -R "rusage[mem=10000]" "snakemake --jobs 12 --cluster \"bsub -q {params.queue} {params.cluster}\" --latency-wait 1200 --timestamp"')

parts_list = glob.glob("*part*fasta")

command_list = []

for x in parts_list:
    command_list.append("trim_reads.pl -i ~/error_model/Coriell_head -f %s -o %s -r ~/error_model/Coriell_error.per -q ~/error_model/Coriell_head.err.qual -m ~/error_model/Coriell_head.err.matr > /dev/null" %(x, (x[:-1] + 'q')))

#added command back in because python seems to wait for commands to finish before heading to next one..?
final_command = ' & '.join(command_list)

#launch trimming of all fastq files in parallel
os.system("%s" %final_command)

#remove fasta parts
os.system("rm -f *part*fasta")

#merge all parts to the final filename, delete all segmented fast parts
os.system("cat *part*fastq | gzip > %s; rm -f *part*fastq" %finalfile)

#then perform seq counts
#os.system("fq_to_count.py %s" %finalfile)

#move files back to cancer genetics
os.system("mv %s %s_seq_counts %s" %(finalfile, file_prefix, cancergenetics))   

#remove original touched file to clean things up a bit
os.system("rm -f %s" %gzlessfile)

#touch filesdone so ouroborous snake knows
os.system("touch filesdone/%s" %finalfile) 
