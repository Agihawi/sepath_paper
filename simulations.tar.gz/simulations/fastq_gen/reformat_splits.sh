#!/bin/bash

#this script will remove line breaks from fasta files

cat *part-01.fasta | awk '!/^>/ { printf "%s", $0; n = "\n" } /^>/ { print n $0; n = "" } END { printf "%s", n }' > part_01.fasta; rm -f *part-01.fasta
cat *part-02.fasta | awk '!/^>/ { printf "%s", $0; n = "\n" } /^>/ { print n $0; n = "" } END { printf "%s", n }' > part_02.fasta; rm -f *part-02.fasta
cat *part-03.fasta | awk '!/^>/ { printf "%s", $0; n = "\n" } /^>/ { print n $0; n = "" } END { printf "%s", n }' > part_03.fasta; rm -f *part-03.fasta
cat *part-04.fasta | awk '!/^>/ { printf "%s", $0; n = "\n" } /^>/ { print n $0; n = "" } END { printf "%s", n }' > part_04.fasta; rm -f *part-04.fasta
cat *part-05.fasta | awk '!/^>/ { printf "%s", $0; n = "\n" } /^>/ { print n $0; n = "" } END { printf "%s", n }' > part_05.fasta; rm -f *part-05.fasta
cat *part-06.fasta | awk '!/^>/ { printf "%s", $0; n = "\n" } /^>/ { print n $0; n = "" } END { printf "%s", n }' > part_06.fasta; rm -f *part-06.fasta
cat *part-07.fasta | awk '!/^>/ { printf "%s", $0; n = "\n" } /^>/ { print n $0; n = "" } END { printf "%s", n }' > part_07.fasta; rm -f *part-07.fasta
cat *part-08.fasta | awk '!/^>/ { printf "%s", $0; n = "\n" } /^>/ { print n $0; n = "" } END { printf "%s", n }' > part_08.fasta; rm -f *part-08.fasta
cat *part-09.fasta | awk '!/^>/ { printf "%s", $0; n = "\n" } /^>/ { print n $0; n = "" } END { printf "%s", n }' > part_09.fasta; rm -f *part-09.fasta
