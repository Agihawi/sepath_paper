#!/usr/bin/env python

import os

launchsnake = 'bsub -J hit_kraken -q long-eth -M 10000 -R "rusage[mem=10000]" "snakemake -s kraken_megahit.snake --cluster \\"bsub -q {params.queue} {params.cluster}\\" --jobs 20 --latency-wait 1200 --timestamp"'

os.system(launchsnake)
