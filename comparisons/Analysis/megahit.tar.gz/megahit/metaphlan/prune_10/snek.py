#!/usr/bin/env python

import os

launchsnake = 'bsub -J prune10_MPH -q long-eth -M 10000 -R "rusage[mem=10000]" "snakemake -s mph_contig.snake --cluster \\"bsub -q {params.queue} {params.cluster}\\" --jobs 20 --latency-wait 1200 --timestamp"'

os.system(launchsnake)
