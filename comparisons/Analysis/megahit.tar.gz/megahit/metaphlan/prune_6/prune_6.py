#!/usr/bin/env python

import os
import glob

FILES=glob.glob('../../../data/prune_6/*_contigs.fa')

for file in FILES:
    prefix = file.split('/')[-1][0:3]
    output = ("%s.mph" %prefix)
    command = "metaphlan2.py --input_type fasta --nproc 6 --min_alignment_len 20 --bowtie2out extra_files/%s.bz --bt2_ps very-sensitive -t rel_ab_w_read_stats %s > output/%s.mph" %(prefix, file, prefix)
    os.system(command)    
